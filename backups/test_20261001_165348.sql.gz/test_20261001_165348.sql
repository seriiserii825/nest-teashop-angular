--
-- PostgreSQL database dump
--

\restrict RgUpEl0BaBAJuCd1T4tesUEkQtRhYoexv3XUeYsrMSGw4LeRaCKMrog1igRiDhM

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: orders_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.orders_status_enum AS ENUM (
    'PENDING',
    'PAYED',
    'CANCELLED'
);


ALTER TYPE public.orders_status_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "storeId" uuid NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: colors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colors (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    value character varying NOT NULL,
    "storeId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.colors OWNER TO postgres;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "orderId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    quantity integer NOT NULL,
    price integer NOT NULL,
    "productId" uuid NOT NULL,
    "storeId" uuid NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    total integer NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "userId" uuid NOT NULL,
    status public.orders_status_enum DEFAULT 'PENDING'::public.orders_status_enum NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    price integer NOT NULL,
    images text NOT NULL,
    "storeId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "categoryId" uuid NOT NULL,
    "colorId" uuid NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    text character varying NOT NULL,
    rating integer NOT NULL,
    "userId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "productId" uuid NOT NULL,
    "storeId" uuid NOT NULL
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: stores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stores (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    "userId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stores OWNER TO postgres;

--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_favorites (
    "usersId" uuid NOT NULL,
    "productsId" uuid NOT NULL
);


ALTER TABLE public.user_favorites OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    picture character varying DEFAULT '/uploads/no-user-image.jpg'::character varying NOT NULL,
    password character varying,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, title, description, "updatedAt", "createdAt", "storeId") FROM stdin;
d0533550-1607-464e-adc3-bcb57994a095	Green Tea	Fresh, lightly oxidized teas	2026-09-29 06:24:41.586832	2026-09-29 06:24:41.586832	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
83d34a4a-a6fa-4f1e-be44-06aca32c4385	Black Tea	Fully oxidized, bold teas	2026-09-29 06:24:41.586832	2026-09-29 06:24:41.586832	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
a23f415e-287d-4fa3-8e81-2f793d97f162	Light Oolong	Floral, lightly roasted oolongs	2026-09-29 06:24:41.596937	2026-09-29 06:24:41.596937	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
b89e04d2-420c-46a4-83ae-c816b8f531d7	Dark Oolong	Roasted, rich and mineral oolongs	2026-09-29 06:24:41.596937	2026-09-29 06:24:41.596937	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
56c92ace-6279-4be2-b825-191642a9c0df	Herbal	Caffeine-free herbal infusions	2026-09-29 06:24:41.604501	2026-09-29 06:24:41.604501	f6862c9e-18de-4eb0-abb9-c055f1a2347e
b84740ed-abd6-4d0a-a7b7-61f0f06797a4	Fruit	Dried fruit and berry blends	2026-09-29 06:24:41.604501	2026-09-29 06:24:41.604501	f6862c9e-18de-4eb0-abb9-c055f1a2347e
2ce42e45-cc8b-4107-9436-bb8b753d1fd7	Ceremonial	Stone-ground matcha for whisking	2026-09-29 06:24:41.609639	2026-09-29 06:24:41.609639	96f49f04-e765-4adf-bc48-937d51b8ce88
fa818cac-9e83-4edc-895a-2d7ea4f3afca	Culinary	Matcha for lattes and baking	2026-09-29 06:24:41.609639	2026-09-29 06:24:41.609639	96f49f04-e765-4adf-bc48-937d51b8ce88
6fdf53c3-dd1c-4dbf-b465-bfe9c6ba685b	Masala Chai	Black tea with warming spices	2026-09-29 06:24:41.61452	2026-09-29 06:24:41.61452	7aed2219-843d-4a8d-86d8-b1784b01bda7
250ac113-fc01-4c38-b99f-1002e782897b	Rooibos Chai	Caffeine-free spiced rooibos	2026-09-29 06:24:41.61452	2026-09-29 06:24:41.61452	7aed2219-843d-4a8d-86d8-b1784b01bda7
52624859-eb76-49b1-9fa9-38a54dc6d5f3	Sheng Pu-erh	Raw pu-erh, bright and evolving	2026-09-29 06:24:41.619423	2026-09-29 06:24:41.619423	9c1c0540-23b0-461c-90fc-18d4c90fed62
7e563e76-f5c2-499a-9de6-829032e7245f	Shou Pu-erh	Ripe pu-erh, earthy and smooth	2026-09-29 06:24:41.619423	2026-09-29 06:24:41.619423	9c1c0540-23b0-461c-90fc-18d4c90fed62
\.


--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.colors (id, name, value, "storeId", "updatedAt", "createdAt") FROM stdin;
794c83c3-90ad-4fa7-acda-389dedcf6a93	Green	#4caf50	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9	2026-09-29 06:24:41.589794	2026-09-29 06:24:41.589794
d30742ba-c21b-41c4-b9a3-559bbbd79f0b	Black	#212121	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9	2026-09-29 06:24:41.589794	2026-09-29 06:24:41.589794
5f12cbe2-31e3-44b3-82bb-152fc94177d1	Jade	#00a86b	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f	2026-09-29 06:24:41.599011	2026-09-29 06:24:41.599011
42fee90d-1e70-41b6-aa75-e1e0a033eb41	Brown	#795548	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f	2026-09-29 06:24:41.599011	2026-09-29 06:24:41.599011
7a61cceb-c27e-4b45-905f-82c14a22ae5b	Amber	#ffb300	f6862c9e-18de-4eb0-abb9-c055f1a2347e	2026-09-29 06:24:41.605791	2026-09-29 06:24:41.605791
eb650569-ffb9-414d-8978-b37b6481de7e	Red	#e53935	f6862c9e-18de-4eb0-abb9-c055f1a2347e	2026-09-29 06:24:41.605791	2026-09-29 06:24:41.605791
119c2ccd-dbf7-403f-b089-b0887b7d0c2c	Emerald	#2e7d32	96f49f04-e765-4adf-bc48-937d51b8ce88	2026-09-29 06:24:41.610838	2026-09-29 06:24:41.610838
e7ad5197-bfde-4a60-b460-295eb64e11bf	Olive	#827717	96f49f04-e765-4adf-bc48-937d51b8ce88	2026-09-29 06:24:41.610838	2026-09-29 06:24:41.610838
1c788fd9-0b20-449b-a3b0-5ca0098140e7	Cinnamon	#d2691e	7aed2219-843d-4a8d-86d8-b1784b01bda7	2026-09-29 06:24:41.615679	2026-09-29 06:24:41.615679
bdc1fb46-54f3-4307-aa99-b9aa868667da	Rust	#b7410e	7aed2219-843d-4a8d-86d8-b1784b01bda7	2026-09-29 06:24:41.615679	2026-09-29 06:24:41.615679
605d777a-a896-47e5-b65a-acfd25ce901c	Gold	#c9a227	9c1c0540-23b0-461c-90fc-18d4c90fed62	2026-09-29 06:24:41.620553	2026-09-29 06:24:41.620553
091a1bcf-c305-442e-b554-fa2ae9745d17	Dark Brown	#3e2723	9c1c0540-23b0-461c-90fc-18d4c90fed62	2026-09-29 06:24:41.620553	2026-09-29 06:24:41.620553
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
5	1788951370896	InitSchema1788951370896
6	1789035959093	ProductCreate1789035959093
7	1789036316376	CreateCategory1789036316376
8	1789036598622	CategoryInStore1789036598622
9	1789036992140	CreateColor1789036992140
10	1789037426949	UserReviews1789037426949
11	1789037568487	UserFavoritesProducts1789037568487
12	1789109282672	ProductReviews1789109282672
13	1789109498256	ReviewsStore1789109498256
14	1789110653625	OrderOrderItems1789110653625
15	1789110781658	OrderUser1789110781658
16	1789110999302	ProductOrderItems1789110999302
17	1789111127556	OrderItemsStore1789111127556
18	1789502352152	StoreTitleUnique1789502352152
19	1789504000249	StoreTitleUniquePerUser1789504000249
20	1789581382969	ColorUniquePerStore1789581382969
21	1789590715493	CategoryTitleUniquePerStore1789590715493
22	1790002986184	CreateUserFavoritesTable1790002986184
23	1790058730925	OrderStatusEnum1790058730925
24	1790058798522	OrderStatusAddCancelled1790058798522
25	1790100000000	ProductDescriptionNotUnique1790100000000
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, "orderId", "updatedAt", "createdAt", quantity, price, "productId", "storeId") FROM stdin;
019f4913-22a3-424f-ac54-417721f6f84d	a4190b5d-7d19-4271-8a38-a16e8807e763	2026-09-29 06:24:41.625594	2026-09-29 06:24:41.625594	1	825	58aa7e0d-f79a-4dc5-bf09-9ee190b8c4c7	f6862c9e-18de-4eb0-abb9-c055f1a2347e
e5652222-1b8b-4a5c-bb14-86e1af218d09	a4190b5d-7d19-4271-8a38-a16e8807e763	2026-09-29 06:24:41.625594	2026-09-29 06:24:41.625594	2	750	cb1be5bc-8515-4bf7-ac3c-a41b6ab39529	f6862c9e-18de-4eb0-abb9-c055f1a2347e
b629657d-9ee3-41ab-a0dd-3241cd4de13d	271e454f-d8e9-40a6-b988-0f1d669d6dd9	2026-09-29 06:24:41.628418	2026-09-29 06:24:41.628418	1	3290	b6c43861-6e33-4179-9fe6-82f3d39691e9	96f49f04-e765-4adf-bc48-937d51b8ce88
40d9a069-ee80-4baf-9117-ebafcda584d5	271e454f-d8e9-40a6-b988-0f1d669d6dd9	2026-09-29 06:24:41.628418	2026-09-29 06:24:41.628418	2	1590	5d8716f8-2816-47d6-8d61-efc6302896b6	96f49f04-e765-4adf-bc48-937d51b8ce88
48116b20-1ab1-4522-925a-08c874afb92f	2dab0ce6-a819-4ec9-b8ec-4fc5a8890801	2026-09-29 06:24:41.630859	2026-09-29 06:24:41.630859	1	990	e8507791-fee4-41fc-8718-283620bbf066	7aed2219-843d-4a8d-86d8-b1784b01bda7
e2eee923-c869-4f44-a3c1-dada8599924e	2dab0ce6-a819-4ec9-b8ec-4fc5a8890801	2026-09-29 06:24:41.630859	2026-09-29 06:24:41.630859	2	1090	19dfc495-7937-4b50-830c-814be8cf926b	7aed2219-843d-4a8d-86d8-b1784b01bda7
1f60fa53-9f79-4eac-8d2e-7957be6c519d	14f11267-0370-4ebe-874e-bc381fb6d502	2026-09-29 06:24:41.633286	2026-09-29 06:24:41.633286	1	3890	9b01b3a7-f3ca-4482-98fc-e45cd4aa62bc	9c1c0540-23b0-461c-90fc-18d4c90fed62
59f2010a-b629-4a05-89ac-c0cad2f8a0d2	14f11267-0370-4ebe-874e-bc381fb6d502	2026-09-29 06:24:41.633286	2026-09-29 06:24:41.633286	2	1290	b4b13e51-8f4e-4ffb-acc2-5a753d96d5a4	9c1c0540-23b0-461c-90fc-18d4c90fed62
c21f03c0-d3b1-4ac8-b978-ef88ffa32dc6	ecd37431-4da8-4ee1-a894-dfe6981a1590	2026-09-29 06:24:41.635675	2026-09-29 06:24:41.635675	1	999	6b4648e4-e56b-4667-8a40-391dc9653978	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
a0cd6fd7-0437-4f4a-a6dc-81c95043bce4	ecd37431-4da8-4ee1-a894-dfe6981a1590	2026-09-29 06:24:41.635675	2026-09-29 06:24:41.635675	2	2450	ab533aba-2d17-4b26-99e2-65988f846e0c	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
7a00af40-0b81-4632-849c-75db1c7a842b	06e779ea-9d67-49d4-8c1c-f995e457a2e6	2026-09-29 06:24:41.63797	2026-09-29 06:24:41.63797	1	1690	66fb4446-d711-4dba-b4c7-469563460970	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
ce834d46-0856-4408-adfd-badf59357a59	06e779ea-9d67-49d4-8c1c-f995e457a2e6	2026-09-29 06:24:41.63797	2026-09-29 06:24:41.63797	2	2190	0c2bbabf-1a72-4d67-8d51-ee85c92b2dcf	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
6f409e59-b3ea-4dbc-8ab0-b7e2f2200b48	690f87ed-5169-4b97-aaaa-7f61e6f4a02d	2026-09-29 06:24:41.640309	2026-09-29 06:24:41.640309	1	990	e8507791-fee4-41fc-8718-283620bbf066	7aed2219-843d-4a8d-86d8-b1784b01bda7
e11fe60f-fa7e-42fc-bc22-f1095175c52e	690f87ed-5169-4b97-aaaa-7f61e6f4a02d	2026-09-29 06:24:41.640309	2026-09-29 06:24:41.640309	2	1090	19dfc495-7937-4b50-830c-814be8cf926b	7aed2219-843d-4a8d-86d8-b1784b01bda7
c12d53c4-1bca-40f4-989d-11ef01e7c8ee	fa154650-cc08-44f5-b13b-4020033aede2	2026-09-29 06:24:41.642621	2026-09-29 06:24:41.642621	1	3890	9b01b3a7-f3ca-4482-98fc-e45cd4aa62bc	9c1c0540-23b0-461c-90fc-18d4c90fed62
fd7c9fbb-6d91-44f1-9482-b7bef6d725a0	fa154650-cc08-44f5-b13b-4020033aede2	2026-09-29 06:24:41.642621	2026-09-29 06:24:41.642621	2	1290	b4b13e51-8f4e-4ffb-acc2-5a753d96d5a4	9c1c0540-23b0-461c-90fc-18d4c90fed62
9110a946-bd06-47ac-ad4b-63922f806879	225c153f-c4f7-4872-896f-57e3901ffa6c	2026-09-29 06:24:41.6449	2026-09-29 06:24:41.6449	1	999	6b4648e4-e56b-4667-8a40-391dc9653978	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
1aec4649-28e8-43ab-92f6-aad2846793c8	225c153f-c4f7-4872-896f-57e3901ffa6c	2026-09-29 06:24:41.6449	2026-09-29 06:24:41.6449	2	2450	ab533aba-2d17-4b26-99e2-65988f846e0c	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
b1283863-99df-4f05-a137-40fc6a078499	baf556fd-3785-4cbc-b490-5901223e39b3	2026-09-29 06:24:41.647202	2026-09-29 06:24:41.647202	1	1690	66fb4446-d711-4dba-b4c7-469563460970	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
e45900bc-0fad-4857-a194-0b839229abc5	baf556fd-3785-4cbc-b490-5901223e39b3	2026-09-29 06:24:41.647202	2026-09-29 06:24:41.647202	2	2190	0c2bbabf-1a72-4d67-8d51-ee85c92b2dcf	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
d867e4dd-5031-4c98-bc21-81e3fb609958	5f4885dc-9058-49f8-b8a9-adb01838624c	2026-09-29 06:24:41.649398	2026-09-29 06:24:41.649398	1	825	58aa7e0d-f79a-4dc5-bf09-9ee190b8c4c7	f6862c9e-18de-4eb0-abb9-c055f1a2347e
0414c120-8d42-4a11-94ad-32e422dbc82a	5f4885dc-9058-49f8-b8a9-adb01838624c	2026-09-29 06:24:41.649398	2026-09-29 06:24:41.649398	2	750	cb1be5bc-8515-4bf7-ac3c-a41b6ab39529	f6862c9e-18de-4eb0-abb9-c055f1a2347e
ef00c52a-a1b5-44e9-89fe-52f45563f9ed	c57c3501-d2dd-41f5-9a78-8f27e24f6e3b	2026-09-29 06:24:41.651783	2026-09-29 06:24:41.651783	1	3290	b6c43861-6e33-4179-9fe6-82f3d39691e9	96f49f04-e765-4adf-bc48-937d51b8ce88
05102cbb-1e9c-4979-b988-6f32afa01329	c57c3501-d2dd-41f5-9a78-8f27e24f6e3b	2026-09-29 06:24:41.651783	2026-09-29 06:24:41.651783	2	1590	5d8716f8-2816-47d6-8d61-efc6302896b6	96f49f04-e765-4adf-bc48-937d51b8ce88
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, total, "updatedAt", "createdAt", "userId", status) FROM stdin;
a4190b5d-7d19-4271-8a38-a16e8807e763	2325	2026-09-29 06:24:41.623405	2026-09-29 06:24:41.623405	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	PENDING
271e454f-d8e9-40a6-b988-0f1d669d6dd9	6470	2026-09-29 06:24:41.627224	2026-09-29 06:24:41.627224	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	PAYED
2dab0ce6-a819-4ec9-b8ec-4fc5a8890801	3170	2026-09-29 06:24:41.629729	2026-09-29 06:24:41.629729	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	CANCELLED
14f11267-0370-4ebe-874e-bc381fb6d502	6470	2026-09-29 06:24:41.63215	2026-09-29 06:24:41.63215	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	PENDING
ecd37431-4da8-4ee1-a894-dfe6981a1590	5899	2026-09-29 06:24:41.634535	2026-09-29 06:24:41.634535	1b1ee05f-a96b-48fb-9b27-7aa55900920e	PENDING
06e779ea-9d67-49d4-8c1c-f995e457a2e6	6070	2026-09-29 06:24:41.636913	2026-09-29 06:24:41.636913	1b1ee05f-a96b-48fb-9b27-7aa55900920e	PAYED
690f87ed-5169-4b97-aaaa-7f61e6f4a02d	3170	2026-09-29 06:24:41.639224	2026-09-29 06:24:41.639224	1b1ee05f-a96b-48fb-9b27-7aa55900920e	CANCELLED
fa154650-cc08-44f5-b13b-4020033aede2	6470	2026-09-29 06:24:41.641533	2026-09-29 06:24:41.641533	1b1ee05f-a96b-48fb-9b27-7aa55900920e	PENDING
225c153f-c4f7-4872-896f-57e3901ffa6c	5899	2026-09-29 06:24:41.643796	2026-09-29 06:24:41.643796	375218e8-a1c9-4349-85a0-26c02f0a83b5	PENDING
baf556fd-3785-4cbc-b490-5901223e39b3	6070	2026-09-29 06:24:41.646122	2026-09-29 06:24:41.646122	375218e8-a1c9-4349-85a0-26c02f0a83b5	PAYED
5f4885dc-9058-49f8-b8a9-adb01838624c	2325	2026-09-29 06:24:41.648346	2026-09-29 06:24:41.648346	375218e8-a1c9-4349-85a0-26c02f0a83b5	CANCELLED
c57c3501-d2dd-41f5-9a78-8f27e24f6e3b	6470	2026-09-29 06:24:41.650628	2026-09-29 06:24:41.650628	375218e8-a1c9-4349-85a0-26c02f0a83b5	PENDING
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, title, description, price, images, "storeId", "updatedAt", "createdAt", "categoryId", "colorId") FROM stdin;
6b4648e4-e56b-4667-8a40-391dc9653978	Sencha Green Tea	Classic Japanese green tea, grassy and fresh	999	https://example.com/sencha.jpg	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9	2026-09-29 06:24:41.592401	2026-09-29 06:24:41.592401	d0533550-1607-464e-adc3-bcb57994a095	794c83c3-90ad-4fa7-acda-389dedcf6a93
ab533aba-2d17-4b26-99e2-65988f846e0c	Gyokuro	Shade-grown Japanese green tea with deep umami	2450	https://example.com/gyokuro.jpg	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9	2026-09-29 06:24:41.592401	2026-09-29 06:24:41.592401	d0533550-1607-464e-adc3-bcb57994a095	794c83c3-90ad-4fa7-acda-389dedcf6a93
8b65fa9b-4630-418a-8550-57afb266c030	Earl Grey	Black tea with bergamot oil	1150	https://example.com/earl-grey.jpg	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9	2026-09-29 06:24:41.592401	2026-09-29 06:24:41.592401	83d34a4a-a6fa-4f1e-be44-06aca32c4385	d30742ba-c21b-41c4-b9a3-559bbbd79f0b
ee465c4b-f1c3-4f8e-9e67-8951d67135e8	English Breakfast	Robust blend of Assam and Ceylon black teas	890	https://example.com/english-breakfast.jpg	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9	2026-09-29 06:24:41.592401	2026-09-29 06:24:41.592401	83d34a4a-a6fa-4f1e-be44-06aca32c4385	d30742ba-c21b-41c4-b9a3-559bbbd79f0b
66fb4446-d711-4dba-b4c7-469563460970	Tie Guan Yin	Iron Goddess oolong with orchid aroma	1690	https://example.com/tie-guan-yin.jpg	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f	2026-09-29 06:24:41.600688	2026-09-29 06:24:41.600688	a23f415e-287d-4fa3-8e81-2f793d97f162	5f12cbe2-31e3-44b3-82bb-152fc94177d1
0c2bbabf-1a72-4d67-8d51-ee85c92b2dcf	Alishan High Mountain	Creamy high-altitude Taiwanese oolong	2190	https://example.com/alishan.jpg	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f	2026-09-29 06:24:41.600688	2026-09-29 06:24:41.600688	a23f415e-287d-4fa3-8e81-2f793d97f162	5f12cbe2-31e3-44b3-82bb-152fc94177d1
1f516d83-a4e5-42e7-956b-9426c78f5e90	Da Hong Pao	Big Red Robe rock oolong from Wuyi mountains	2790	https://example.com/da-hong-pao.jpg	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f	2026-09-29 06:24:41.600688	2026-09-29 06:24:41.600688	b89e04d2-420c-46a4-83ae-c816b8f531d7	42fee90d-1e70-41b6-aa75-e1e0a033eb41
58aa7e0d-f79a-4dc5-bf09-9ee190b8c4c7	Chamomile Blend	Soothing chamomile and honey herbal tea	825	https://example.com/chamomile.jpg	f6862c9e-18de-4eb0-abb9-c055f1a2347e	2026-09-29 06:24:41.607085	2026-09-29 06:24:41.607085	56c92ace-6279-4be2-b825-191642a9c0df	7a61cceb-c27e-4b45-905f-82c14a22ae5b
cb1be5bc-8515-4bf7-ac3c-a41b6ab39529	Peppermint Leaf	Cooling whole peppermint leaves	750	https://example.com/peppermint.jpg	f6862c9e-18de-4eb0-abb9-c055f1a2347e	2026-09-29 06:24:41.607085	2026-09-29 06:24:41.607085	56c92ace-6279-4be2-b825-191642a9c0df	7a61cceb-c27e-4b45-905f-82c14a22ae5b
6f3b1ad5-a29f-433e-b4c0-ff6a32147d8d	Berry Burst	Hibiscus, raspberry and blackcurrant infusion	950	https://example.com/berry-burst.jpg	f6862c9e-18de-4eb0-abb9-c055f1a2347e	2026-09-29 06:24:41.607085	2026-09-29 06:24:41.607085	b84740ed-abd6-4d0a-a7b7-61f0f06797a4	eb650569-ffb9-414d-8978-b37b6481de7e
b6c43861-6e33-4179-9fe6-82f3d39691e9	Uji Ceremonial Matcha	Vibrant first-harvest matcha from Uji, Kyoto	3290	https://example.com/uji-matcha.jpg	96f49f04-e765-4adf-bc48-937d51b8ce88	2026-09-29 06:24:41.612045	2026-09-29 06:24:41.612045	2ce42e45-cc8b-4107-9436-bb8b753d1fd7	119c2ccd-dbf7-403f-b089-b0887b7d0c2c
5d8716f8-2816-47d6-8d61-efc6302896b6	Latte Matcha	Bold matcha blend made for milk drinks	1590	https://example.com/latte-matcha.jpg	96f49f04-e765-4adf-bc48-937d51b8ce88	2026-09-29 06:24:41.612045	2026-09-29 06:24:41.612045	fa818cac-9e83-4edc-895a-2d7ea4f3afca	e7ad5197-bfde-4a60-b460-295eb64e11bf
92b681d6-5dd7-44f5-b269-87761b5589a0	Baking Matcha	Economical matcha powder for desserts	1190	https://example.com/baking-matcha.jpg	96f49f04-e765-4adf-bc48-937d51b8ce88	2026-09-29 06:24:41.612045	2026-09-29 06:24:41.612045	fa818cac-9e83-4edc-895a-2d7ea4f3afca	e7ad5197-bfde-4a60-b460-295eb64e11bf
e8507791-fee4-41fc-8718-283620bbf066	Classic Masala Chai	Assam with cardamom, ginger and clove	990	https://example.com/masala-chai.jpg	7aed2219-843d-4a8d-86d8-b1784b01bda7	2026-09-29 06:24:41.616882	2026-09-29 06:24:41.616882	6fdf53c3-dd1c-4dbf-b465-bfe9c6ba685b	1c788fd9-0b20-449b-a3b0-5ca0098140e7
19dfc495-7937-4b50-830c-814be8cf926b	Vanilla Chai	Masala chai softened with Madagascar vanilla	1090	https://example.com/vanilla-chai.jpg	7aed2219-843d-4a8d-86d8-b1784b01bda7	2026-09-29 06:24:41.616882	2026-09-29 06:24:41.616882	6fdf53c3-dd1c-4dbf-b465-bfe9c6ba685b	1c788fd9-0b20-449b-a3b0-5ca0098140e7
23e42f5d-bf28-4893-ae31-0b6752cdee66	Rooibos Chai	South African rooibos with chai spices	870	https://example.com/rooibos-chai.jpg	7aed2219-843d-4a8d-86d8-b1784b01bda7	2026-09-29 06:24:41.616882	2026-09-29 06:24:41.616882	250ac113-fc01-4c38-b99f-1002e782897b	bdc1fb46-54f3-4307-aa99-b9aa868667da
9b01b3a7-f3ca-4482-98fc-e45cd4aa62bc	Menghai Sheng 2018	Raw pu-erh cake from Menghai, pressed in 2018	3890	https://example.com/menghai-sheng.jpg	9c1c0540-23b0-461c-90fc-18d4c90fed62	2026-09-29 06:24:41.621804	2026-09-29 06:24:41.621804	52624859-eb76-49b1-9fa9-38a54dc6d5f3	605d777a-a896-47e5-b65a-acfd25ce901c
b4b13e51-8f4e-4ffb-acc2-5a753d96d5a4	Ripe Mini Tuocha	Single-serve ripe pu-erh nests	1290	https://example.com/mini-tuocha.jpg	9c1c0540-23b0-461c-90fc-18d4c90fed62	2026-09-29 06:24:41.621804	2026-09-29 06:24:41.621804	7e563e76-f5c2-499a-9de6-829032e7245f	091a1bcf-c305-442e-b554-fa2ae9745d17
9287f864-d84d-4114-af26-a2a97aff889b	Palace Shou Pu-erh	Fine-leaf ripe pu-erh with chocolate notes	2190	https://example.com/palace-shou.jpg	9c1c0540-23b0-461c-90fc-18d4c90fed62	2026-09-29 06:24:41.621804	2026-09-29 06:24:41.621804	7e563e76-f5c2-499a-9de6-829032e7245f	091a1bcf-c305-442e-b554-fa2ae9745d17
96550945-0d33-4c40-b3f1-ac2c5cb37226	Puma	Puma shoes	1450	/uploads/products/1790837990995-puma-1.jpg,/uploads/products/1790837990996-puma-2.jpg	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f	2026-10-01 06:59:53.455556	2026-10-01 06:59:53.455556	a23f415e-287d-4fa3-8e81-2f793d97f162	42fee90d-1e70-41b6-aa75-e1e0a033eb41
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, text, rating, "userId", "updatedAt", "createdAt", "productId", "storeId") FROM stdin;
7b0f393c-51f9-4d7f-9bb2-d24034199f07	Great flavor, will buy again!	5	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	6b4648e4-e56b-4667-8a40-391dc9653978	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
b9e4b91c-0951-431e-b9fb-5a912392c2e5	Nice notes, brews smooth.	4	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	6b4648e4-e56b-4667-8a40-391dc9653978	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
5c1e28f2-775a-420c-a979-7fe9cf509786	A bit weak for my taste, but decent.	3	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	ab533aba-2d17-4b26-99e2-65988f846e0c	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
4da90401-d1cd-4014-9fcd-e45d06bb4010	Good but a bit pricey.	4	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	ab533aba-2d17-4b26-99e2-65988f846e0c	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
45cf5e6f-a4d2-4d3f-8974-f159cfa96c61	Absolutely love it, my daily cup.	5	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	8b65fa9b-4630-418a-8550-57afb266c030	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
1a265bcf-13b1-40eb-941c-0c5fb744f776	Great flavor, will buy again!	5	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	8b65fa9b-4630-418a-8550-57afb266c030	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
d5b4ee31-39b8-4293-a5c2-996abfd911c7	Nice notes, brews smooth.	4	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	ee465c4b-f1c3-4f8e-9e67-8951d67135e8	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
fe619064-9328-49c3-ad45-7d4fc7212929	A bit weak for my taste, but decent.	3	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	ee465c4b-f1c3-4f8e-9e67-8951d67135e8	bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9
425ba3b4-9d0e-4bf5-999b-cc44b15623c7	Good but a bit pricey.	4	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	66fb4446-d711-4dba-b4c7-469563460970	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
af5e7a5b-4e41-4f1c-b487-5fc1b4539e00	Absolutely love it, my daily cup.	5	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	66fb4446-d711-4dba-b4c7-469563460970	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
43dea269-4465-4c81-a100-3ba12a367cc3	Great flavor, will buy again!	5	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	0c2bbabf-1a72-4d67-8d51-ee85c92b2dcf	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
76d3f61b-f812-417d-9170-77e8ff82218b	Nice notes, brews smooth.	4	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	0c2bbabf-1a72-4d67-8d51-ee85c92b2dcf	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
a2a3f53f-a587-4eca-893b-228549e9215c	A bit weak for my taste, but decent.	3	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	1f516d83-a4e5-42e7-956b-9426c78f5e90	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
47100a58-ccc5-4853-8abc-eacad5e86707	Good but a bit pricey.	4	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	1f516d83-a4e5-42e7-956b-9426c78f5e90	0d5ff8d1-7d57-412a-a451-f6c34f0fa98f
5c844d96-9404-451c-bd55-f0091e4b1418	Absolutely love it, my daily cup.	5	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	58aa7e0d-f79a-4dc5-bf09-9ee190b8c4c7	f6862c9e-18de-4eb0-abb9-c055f1a2347e
f59715cb-5e69-4b6d-9285-29056dda6de2	Great flavor, will buy again!	5	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	58aa7e0d-f79a-4dc5-bf09-9ee190b8c4c7	f6862c9e-18de-4eb0-abb9-c055f1a2347e
3c5dff43-4b1e-4d05-aefe-e029439425d6	Nice notes, brews smooth.	4	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	cb1be5bc-8515-4bf7-ac3c-a41b6ab39529	f6862c9e-18de-4eb0-abb9-c055f1a2347e
e66ad8f9-a65f-495d-993c-d5a6820bb267	A bit weak for my taste, but decent.	3	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	cb1be5bc-8515-4bf7-ac3c-a41b6ab39529	f6862c9e-18de-4eb0-abb9-c055f1a2347e
ac8867a7-2837-4b91-b96e-5aad5feb5e1d	Good but a bit pricey.	4	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	6f3b1ad5-a29f-433e-b4c0-ff6a32147d8d	f6862c9e-18de-4eb0-abb9-c055f1a2347e
c521d982-d54d-41fd-b5f0-33517b80a942	Absolutely love it, my daily cup.	5	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	6f3b1ad5-a29f-433e-b4c0-ff6a32147d8d	f6862c9e-18de-4eb0-abb9-c055f1a2347e
46506f01-8d98-455c-9368-0f2845fee323	Great flavor, will buy again!	5	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	b6c43861-6e33-4179-9fe6-82f3d39691e9	96f49f04-e765-4adf-bc48-937d51b8ce88
f1885810-4cba-4cdd-8413-c4f3ec36e958	Nice notes, brews smooth.	4	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	b6c43861-6e33-4179-9fe6-82f3d39691e9	96f49f04-e765-4adf-bc48-937d51b8ce88
18093bf9-b1bf-4b8b-b52b-13a45bc72168	A bit weak for my taste, but decent.	3	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	5d8716f8-2816-47d6-8d61-efc6302896b6	96f49f04-e765-4adf-bc48-937d51b8ce88
29812de3-1a8b-46ee-8523-1687705f351f	Good but a bit pricey.	4	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	5d8716f8-2816-47d6-8d61-efc6302896b6	96f49f04-e765-4adf-bc48-937d51b8ce88
bd31c7f5-0785-48ea-a392-e1a1b6146639	Absolutely love it, my daily cup.	5	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	92b681d6-5dd7-44f5-b269-87761b5589a0	96f49f04-e765-4adf-bc48-937d51b8ce88
eb1aef15-63f4-43f9-b15b-e84121b22300	Great flavor, will buy again!	5	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	92b681d6-5dd7-44f5-b269-87761b5589a0	96f49f04-e765-4adf-bc48-937d51b8ce88
349b77d7-73a2-4b91-b7a7-0bec436c26d7	Nice notes, brews smooth.	4	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	e8507791-fee4-41fc-8718-283620bbf066	7aed2219-843d-4a8d-86d8-b1784b01bda7
90cac67a-ff9b-40fc-a933-ca0fe3428423	A bit weak for my taste, but decent.	3	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	e8507791-fee4-41fc-8718-283620bbf066	7aed2219-843d-4a8d-86d8-b1784b01bda7
9cb94d34-dd85-474d-b889-9008106148aa	Good but a bit pricey.	4	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	19dfc495-7937-4b50-830c-814be8cf926b	7aed2219-843d-4a8d-86d8-b1784b01bda7
039a4886-6386-4ff4-92a6-16c8f6fbdb6a	Absolutely love it, my daily cup.	5	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	19dfc495-7937-4b50-830c-814be8cf926b	7aed2219-843d-4a8d-86d8-b1784b01bda7
60907331-6a9d-4163-b32b-64037d566dba	Great flavor, will buy again!	5	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	23e42f5d-bf28-4893-ae31-0b6752cdee66	7aed2219-843d-4a8d-86d8-b1784b01bda7
0c4322be-6274-4042-8715-029b4825074c	Nice notes, brews smooth.	4	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	23e42f5d-bf28-4893-ae31-0b6752cdee66	7aed2219-843d-4a8d-86d8-b1784b01bda7
709e78cc-0a67-4a33-af5c-6848a807dca7	A bit weak for my taste, but decent.	3	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	9b01b3a7-f3ca-4482-98fc-e45cd4aa62bc	9c1c0540-23b0-461c-90fc-18d4c90fed62
d1ce662f-ce31-4837-a1b2-fb85959d98c7	Good but a bit pricey.	4	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	9b01b3a7-f3ca-4482-98fc-e45cd4aa62bc	9c1c0540-23b0-461c-90fc-18d4c90fed62
c1692688-0d1b-4035-8f2e-8b96a6cbd577	Absolutely love it, my daily cup.	5	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	b4b13e51-8f4e-4ffb-acc2-5a753d96d5a4	9c1c0540-23b0-461c-90fc-18d4c90fed62
2b5237ee-8b7e-40dd-98d7-7714d03c242a	Great flavor, will buy again!	5	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	b4b13e51-8f4e-4ffb-acc2-5a753d96d5a4	9c1c0540-23b0-461c-90fc-18d4c90fed62
c2b70337-9efa-429c-9c1e-b6944e313eeb	Nice notes, brews smooth.	4	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	9287f864-d84d-4114-af26-a2a97aff889b	9c1c0540-23b0-461c-90fc-18d4c90fed62
75c6fbd9-a7ad-4845-992e-a902d0582f84	A bit weak for my taste, but decent.	3	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.653693	2026-09-29 06:24:41.653693	9287f864-d84d-4114-af26-a2a97aff889b	9c1c0540-23b0-461c-90fc-18d4c90fed62
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stores (id, title, description, "userId", "updatedAt", "createdAt") FROM stdin;
bc2a09a9-b0d0-4f89-bfd1-a8bc33da3cb9	Serii Tea House	Loose leaf teas from around the world	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.57725	2026-09-29 06:24:41.57725
0d5ff8d1-7d57-412a-a451-f6c34f0fa98f	Serii Oolong Corner	Hand-picked oolongs from Taiwan and Fujian	e34c4610-1e39-4bd8-bab6-7fe8ac30db02	2026-09-29 06:24:41.595484	2026-09-29 06:24:41.595484
f6862c9e-18de-4eb0-abb9-c055f1a2347e	Nixon Herbal Shop	Herbal blends and infusions	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.603049	2026-09-29 06:24:41.603049
96f49f04-e765-4adf-bc48-937d51b8ce88	Nixon Matcha Bar	Ceremonial and culinary grade matcha	1b1ee05f-a96b-48fb-9b27-7aa55900920e	2026-09-29 06:24:41.608532	2026-09-29 06:24:41.608532
7aed2219-843d-4a8d-86d8-b1784b01bda7	Buyer Chai Corner	Spiced chai blends inspired by India	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.613411	2026-09-29 06:24:41.613411
9c1c0540-23b0-461c-90fc-18d4c90fed62	Buyer Pu-erh Cellar	Aged and fermented teas from Yunnan	375218e8-a1c9-4349-85a0-26c02f0a83b5	2026-09-29 06:24:41.618311	2026-09-29 06:24:41.618311
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_favorites ("usersId", "productsId") FROM stdin;
e34c4610-1e39-4bd8-bab6-7fe8ac30db02	58aa7e0d-f79a-4dc5-bf09-9ee190b8c4c7
e34c4610-1e39-4bd8-bab6-7fe8ac30db02	b6c43861-6e33-4179-9fe6-82f3d39691e9
e34c4610-1e39-4bd8-bab6-7fe8ac30db02	e8507791-fee4-41fc-8718-283620bbf066
e34c4610-1e39-4bd8-bab6-7fe8ac30db02	9b01b3a7-f3ca-4482-98fc-e45cd4aa62bc
1b1ee05f-a96b-48fb-9b27-7aa55900920e	6b4648e4-e56b-4667-8a40-391dc9653978
1b1ee05f-a96b-48fb-9b27-7aa55900920e	66fb4446-d711-4dba-b4c7-469563460970
1b1ee05f-a96b-48fb-9b27-7aa55900920e	e8507791-fee4-41fc-8718-283620bbf066
1b1ee05f-a96b-48fb-9b27-7aa55900920e	9b01b3a7-f3ca-4482-98fc-e45cd4aa62bc
375218e8-a1c9-4349-85a0-26c02f0a83b5	6b4648e4-e56b-4667-8a40-391dc9653978
375218e8-a1c9-4349-85a0-26c02f0a83b5	66fb4446-d711-4dba-b4c7-469563460970
375218e8-a1c9-4349-85a0-26c02f0a83b5	58aa7e0d-f79a-4dc5-bf09-9ee190b8c4c7
375218e8-a1c9-4349-85a0-26c02f0a83b5	b6c43861-6e33-4179-9fe6-82f3d39691e9
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, picture, password, "updatedAt", "createdAt") FROM stdin;
e34c4610-1e39-4bd8-bab6-7fe8ac30db02	Serii	seriiburduja@gmail.com	/uploads/no-user-image.jpg	$argon2id$v=19$m=65536,p=4,t=3$0gQh+fL/zhIkuJsNJT3Z2A$yAlZXH6KGzgxWmy4SiAHmNbsGk44ksEBmOY+UXh5kEw	2026-09-29 06:24:41.565259	2026-09-29 06:24:41.565259
1b1ee05f-a96b-48fb-9b27-7aa55900920e	Nixon	nixon@gmail.com	/uploads/no-user-image.jpg	$argon2id$v=19$m=65536,p=4,t=3$0gQh+fL/zhIkuJsNJT3Z2A$yAlZXH6KGzgxWmy4SiAHmNbsGk44ksEBmOY+UXh5kEw	2026-09-29 06:24:41.565259	2026-09-29 06:24:41.565259
375218e8-a1c9-4349-85a0-26c02f0a83b5	Buyer	buyer@example.com	/uploads/no-user-image.jpg	$argon2id$v=19$m=65536,p=4,t=3$0gQh+fL/zhIkuJsNJT3Z2A$yAlZXH6KGzgxWmy4SiAHmNbsGk44ksEBmOY+UXh5kEw	2026-09-29 06:24:41.565259	2026-09-29 06:24:41.565259
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 25, true);


--
-- Name: order_items PK_005269d8574e6fac0493715c308; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "PK_005269d8574e6fac0493715c308" PRIMARY KEY (id);


--
-- Name: products PK_0806c755e0aca124e67c0cf6d7d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "PK_0806c755e0aca124e67c0cf6d7d" PRIMARY KEY (id);


--
-- Name: reviews PK_231ae565c273ee700b283f15c1d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "PK_231ae565c273ee700b283f15c1d" PRIMARY KEY (id);


--
-- Name: categories PK_24dbc6126a28ff948da33e97d3b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "PK_24dbc6126a28ff948da33e97d3b" PRIMARY KEY (id);


--
-- Name: colors PK_3a62edc12d29307872ab1777ced; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "PK_3a62edc12d29307872ab1777ced" PRIMARY KEY (id);


--
-- Name: user_favorites PK_5065e45fbc2a1f3e58a6fd9a430; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT "PK_5065e45fbc2a1f3e58a6fd9a430" PRIMARY KEY ("usersId", "productsId");


--
-- Name: orders PK_710e2d4957aa5878dfe94e4ac2f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "PK_710e2d4957aa5878dfe94e4ac2f" PRIMARY KEY (id);


--
-- Name: stores PK_7aa6e7d71fa7acdd7ca43d7c9cb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT "PK_7aa6e7d71fa7acdd7ca43d7c9cb" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: categories UQ_00cd8c23464066489091473647d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "UQ_00cd8c23464066489091473647d" UNIQUE ("storeId", title);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: stores UQ_9f50895fbf54f7218dfa5b66e48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT "UQ_9f50895fbf54f7218dfa5b66e48" UNIQUE ("userId", title);


--
-- Name: colors UQ_d0546798ebd98f0ffb35f3a2f0c; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "UQ_d0546798ebd98f0ffb35f3a2f0c" UNIQUE ("storeId", name);


--
-- Name: IDX_152cb1955a8e956ffb7645fdf4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_152cb1955a8e956ffb7645fdf4" ON public.user_favorites USING btree ("productsId");


--
-- Name: IDX_9b10bf53f6d16b355ce259098d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_9b10bf53f6d16b355ce259098d" ON public.user_favorites USING btree ("usersId");


--
-- Name: orders FK_151b79a83ba240b0cb31b2302d1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "FK_151b79a83ba240b0cb31b2302d1" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_favorites FK_152cb1955a8e956ffb7645fdf40; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT "FK_152cb1955a8e956ffb7645fdf40" FOREIGN KEY ("productsId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews FK_375e254056be23e89da0ef9ce13; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_375e254056be23e89da0ef9ce13" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: colors FK_517a6de81f2486324e0cdf5f0bd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "FK_517a6de81f2486324e0cdf5f0bd" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: order_items FK_76b4a6406b4a79c62d165260a9c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_76b4a6406b4a79c62d165260a9c" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: products FK_782da5e50e94b763eb63225d69d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_782da5e50e94b763eb63225d69d" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: reviews FK_7ed5659e7139fc8bc039198cc1f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_7ed5659e7139fc8bc039198cc1f" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: products FK_977ca0c3cae8850c2a5f49e3f13; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_977ca0c3cae8850c2a5f49e3f13" FOREIGN KEY ("colorId") REFERENCES public.colors(id) ON DELETE CASCADE;


--
-- Name: user_favorites FK_9b10bf53f6d16b355ce259098d0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT "FK_9b10bf53f6d16b355ce259098d0" FOREIGN KEY ("usersId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews FK_a6b3c434392f5d10ec171043666; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_a6b3c434392f5d10ec171043666" FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: order_items FK_cdb99c05982d5191ac8465ac010; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_cdb99c05982d5191ac8465ac010" FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: order_items FK_f1d359a55923bb45b057fbdab0d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_f1d359a55923bb45b057fbdab0d" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: stores FK_f36d697e265ed99b80cae6984c9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT "FK_f36d697e265ed99b80cae6984c9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: categories FK_fa6ba3528de12e174b163c09fdd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "FK_fa6ba3528de12e174b163c09fdd" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: products FK_ff56834e735fa78a15d0cf21926; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_ff56834e735fa78a15d0cf21926" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict RgUpEl0BaBAJuCd1T4tesUEkQtRhYoexv3XUeYsrMSGw4LeRaCKMrog1igRiDhM

