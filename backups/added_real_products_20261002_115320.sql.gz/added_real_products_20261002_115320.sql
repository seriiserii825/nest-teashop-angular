--
-- PostgreSQL database dump
--

\restrict DdPpdM3koGHbKOPHGAwL9BA1QDlSF8Ixa3KfmvhovULqtnmCsQdNJzUoKvq811L

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg13+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: orders_status_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.orders_status_enum AS ENUM (
    'PENDING',
    'PAYED',
    'CANCELLED'
);


ALTER TYPE public.orders_status_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "storeId" uuid NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: colors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colors (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    value character varying NOT NULL,
    "storeId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.colors OWNER TO postgres;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "orderId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    quantity integer NOT NULL,
    price integer NOT NULL,
    "productId" uuid NOT NULL,
    "storeId" uuid NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    total integer NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "userId" uuid NOT NULL,
    status public.orders_status_enum DEFAULT 'PENDING'::public.orders_status_enum NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    price integer NOT NULL,
    images text NOT NULL,
    "storeId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "categoryId" uuid NOT NULL,
    "colorId" uuid NOT NULL,
    slug character varying NOT NULL,
    CONSTRAINT "CHK_457f556dde111a9d56b9a34b91" CHECK (((slug)::text ~ '^[a-z0-9]+(-[a-z0-9]+)*$'::text))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    text character varying NOT NULL,
    rating integer NOT NULL,
    "userId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "productId" uuid NOT NULL,
    "storeId" uuid NOT NULL
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: stores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stores (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    "userId" uuid NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stores OWNER TO postgres;

--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_favorites (
    "usersId" uuid NOT NULL,
    "productsId" uuid NOT NULL
);


ALTER TABLE public.user_favorites OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    picture character varying DEFAULT '/uploads/no-user-image.jpg'::character varying NOT NULL,
    password character varying,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, title, description, "updatedAt", "createdAt", "storeId") FROM stdin;
21059122-9014-4cf3-9e48-d141c64e1517	Shirts	Casual and formal shirts	2026-10-02 08:41:29.783181	2026-10-02 08:41:29.783181	85c0cfdf-2858-49ab-94ff-87ff644d1560
56328406-be28-4be4-ae97-e37494797c2b	Dresses	Dresses, frocks and suits	2026-10-02 08:41:29.783181	2026-10-02 08:41:29.783181	85c0cfdf-2858-49ab-94ff-87ff644d1560
37f81f51-2632-4efc-9c54-26bfb6f63978	Sneakers	Sport and everyday sneakers	2026-10-02 08:41:29.783181	2026-10-02 08:41:29.783181	85c0cfdf-2858-49ab-94ff-87ff644d1560
8b79dbff-fc96-4a2c-9dbd-e31727f550b6	Bags	Handbags and backpacks	2026-10-02 08:41:29.783181	2026-10-02 08:41:29.783181	85c0cfdf-2858-49ab-94ff-87ff644d1560
9a802ef1-b3dc-4746-8548-8de0f05bb18e	Sunglasses	Sunglasses with UV protection	2026-10-02 08:41:29.783181	2026-10-02 08:41:29.783181	85c0cfdf-2858-49ab-94ff-87ff644d1560
18d46c8b-d817-48f2-be49-f711cf950405	Shirts	Casual and formal shirts	2026-10-02 08:41:29.795151	2026-10-02 08:41:29.795151	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
c9c73a79-73c4-4332-9531-3440a7ec17a5	Dresses	Dresses, frocks and suits	2026-10-02 08:41:29.795151	2026-10-02 08:41:29.795151	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
9d83c9f7-3170-402c-8813-d0fe35564806	Sneakers	Sport and everyday sneakers	2026-10-02 08:41:29.795151	2026-10-02 08:41:29.795151	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
b48ef826-7196-41eb-8fe5-e40732151acf	Women's Shoes	Heels, flats and slippers	2026-10-02 08:41:29.795151	2026-10-02 08:41:29.795151	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
02b3261d-d2b4-4fed-8150-89196a6c2057	Bags	Handbags and backpacks	2026-10-02 08:41:29.795151	2026-10-02 08:41:29.795151	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
35eacf02-538f-468a-9332-05b9e8f63de3	Sunglasses	Sunglasses with UV protection	2026-10-02 08:41:29.795151	2026-10-02 08:41:29.795151	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
\.


--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.colors (id, name, value, "storeId", "updatedAt", "createdAt") FROM stdin;
cd63d325-f338-4d20-bfd6-8ec78caf4f5d	Black	#212121	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.786304	2026-10-02 08:41:29.786304
636bd3ea-858e-42c2-8a14-336cac304458	White	#fafafa	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.786304	2026-10-02 08:41:29.786304
476ddedb-79eb-49a8-a1a8-f27c3dc45c16	Red	#e53935	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.786304	2026-10-02 08:41:29.786304
06a6864a-460f-4413-8987-a49fa0e7ae0a	Blue	#1e88e5	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.786304	2026-10-02 08:41:29.786304
a0ba32b2-7507-4033-ac5c-80f2b8bf4307	Gray	#9e9e9e	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.786304	2026-10-02 08:41:29.786304
97755195-ea34-4fe3-96e3-b4fed03e6a21	Black	#212121	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.797111	2026-10-02 08:41:29.797111
116f1764-9313-4a05-9eed-80c2309b4b01	White	#fafafa	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.797111	2026-10-02 08:41:29.797111
e346d242-2e56-4d7c-a81c-40dad2387e32	Red	#e53935	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.797111	2026-10-02 08:41:29.797111
f0bc81a0-15ef-49c6-92be-b07a436f6101	Gray	#9e9e9e	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.797111	2026-10-02 08:41:29.797111
ed57d8bc-99b3-494b-94d3-8a2b4f8c9e64	Brown	#795548	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.797111	2026-10-02 08:41:29.797111
0a3ee5ab-3fd7-4944-89a2-6bde2f7b141c	Gold	#c9a227	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.797111	2026-10-02 08:41:29.797111
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
5	1788951370896	InitSchema1788951370896
6	1789035959093	ProductCreate1789035959093
7	1789036316376	CreateCategory1789036316376
8	1789036598622	CategoryInStore1789036598622
9	1789036992140	CreateColor1789036992140
10	1789037426949	UserReviews1789037426949
11	1789037568487	UserFavoritesProducts1789037568487
12	1789109282672	ProductReviews1789109282672
13	1789109498256	ReviewsStore1789109498256
14	1789110653625	OrderOrderItems1789110653625
15	1789110781658	OrderUser1789110781658
16	1789110999302	ProductOrderItems1789110999302
17	1789111127556	OrderItemsStore1789111127556
18	1789502352152	StoreTitleUnique1789502352152
19	1789504000249	StoreTitleUniquePerUser1789504000249
20	1789581382969	ColorUniquePerStore1789581382969
21	1789590715493	CategoryTitleUniquePerStore1789590715493
22	1790002986184	CreateUserFavoritesTable1790002986184
23	1790058730925	OrderStatusEnum1790058730925
24	1790058798522	OrderStatusAddCancelled1790058798522
25	1790100000000	ProductDescriptionNotUnique1790100000000
27	1790200000000	ProductSlugUniquePerStore1790200000000
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, "orderId", "updatedAt", "createdAt", quantity, price, "productId", "storeId") FROM stdin;
7b652bf2-349d-47f3-ac30-3d41c537e762	f6f6ec1f-c877-4b5e-8168-70a969585b1f	2026-10-02 08:41:29.805524	2026-10-02 08:41:29.805524	1	3290	38721858-1398-4f0d-8f3a-e0182193972e	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
a1359c43-99d6-4ba7-96df-82ccdc62bd19	f6f6ec1f-c877-4b5e-8168-70a969585b1f	2026-10-02 08:41:29.805524	2026-10-02 08:41:29.805524	2	8990	94e991cf-6b8b-4251-ba27-aef66a93c085	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
e413fafa-8978-4f4f-b229-b8dde9c9864e	55ff8333-ef77-477e-b2f9-e8979ed502c2	2026-10-02 08:41:29.808858	2026-10-02 08:41:29.808858	1	2990	1950b3cf-3fb3-4728-adc8-c033ffc297a6	85c0cfdf-2858-49ab-94ff-87ff644d1560
022eb053-3e6a-4c42-9d49-4c73653686c1	55ff8333-ef77-477e-b2f9-e8979ed502c2	2026-10-02 08:41:29.808858	2026-10-02 08:41:29.808858	2	3490	cc60c459-3e8b-44f1-a119-e5501a533b9f	85c0cfdf-2858-49ab-94ff-87ff644d1560
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, total, "updatedAt", "createdAt", "userId", status) FROM stdin;
f6f6ec1f-c877-4b5e-8168-70a969585b1f	21270	2026-10-02 08:41:29.803218	2026-10-02 08:41:29.803218	054b8fdd-42a7-4108-bd69-c74599b5c616	PENDING
55ff8333-ef77-477e-b2f9-e8979ed502c2	9970	2026-10-02 08:41:29.807631	2026-10-02 08:41:29.807631	f696a8a0-4279-4dbf-8e63-4767ea6e223f	PENDING
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, title, description, price, images, "storeId", "updatedAt", "createdAt", "categoryId", "colorId", slug) FROM stdin;
1950b3cf-3fb3-4728-adc8-c033ffc297a6	Blue & Black Check Shirt	Classic check shirt for casual and semi-formal looks	2990	https://cdn.dummyjson.com/product-images/mens-shirts/blue-&-black-check-shirt/1.webp	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.789516	2026-10-02 08:41:29.789516	21059122-9014-4cf3-9e48-d141c64e1517	06a6864a-460f-4413-8987-a49fa0e7ae0a	blue-black-check-shirt
cc60c459-3e8b-44f1-a119-e5501a533b9f	Man Plaid Shirt	Timeless plaid shirt with a comfortable fit	3490	https://cdn.dummyjson.com/product-images/mens-shirts/man-plaid-shirt/1.webp	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.789516	2026-10-02 08:41:29.789516	21059122-9014-4cf3-9e48-d141c64e1517	476ddedb-79eb-49a8-a1a8-f27c3dc45c16	man-plaid-shirt
db8d2949-6204-4e6b-908c-00e6489421df	Blue Frock	Charming blue frock for any occasion	3990	https://cdn.dummyjson.com/product-images/tops/blue-frock/1.webp	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.789516	2026-10-02 08:41:29.789516	56328406-be28-4be4-ae97-e37494797c2b	06a6864a-460f-4413-8987-a49fa0e7ae0a	blue-frock
76260181-938b-4e65-a418-c369f68c7e0b	Nike Air Jordan 1 Red And Black	Iconic basketball sneaker in red and black	14990	https://cdn.dummyjson.com/product-images/mens-shoes/nike-air-jordan-1-red-and-black/1.webp	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.789516	2026-10-02 08:41:29.789516	37f81f51-2632-4efc-9c54-26bfb6f63978	476ddedb-79eb-49a8-a1a8-f27c3dc45c16	nike-air-jordan-1-red-and-black
a798019d-68bb-4edb-b9e7-1a9c9266a460	Puma Future Rider Trainers	Retro-styled trainers with modern comfort	8990	https://cdn.dummyjson.com/product-images/mens-shoes/puma-future-rider-trainers/1.webp	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.789516	2026-10-02 08:41:29.789516	37f81f51-2632-4efc-9c54-26bfb6f63978	a0ba32b2-7507-4033-ac5c-80f2b8bf4307	puma-future-rider-trainers
b3dda725-5339-407e-bedb-e89f450d1b90	Women Handbag Black	Classic black handbag that fits any outfit	5990	https://cdn.dummyjson.com/product-images/womens-bags/women-handbag-black/1.webp	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.789516	2026-10-02 08:41:29.789516	8b79dbff-fc96-4a2c-9dbd-e31727f550b6	cd63d325-f338-4d20-bfd6-8ec78caf4f5d	women-handbag-black
97940df8-d462-4f2c-afe9-0c788ada292e	Black Sun Glasses	Sleek black frame with tinted UV lenses	2490	https://cdn.dummyjson.com/product-images/sunglasses/black-sun-glasses/1.webp	85c0cfdf-2858-49ab-94ff-87ff644d1560	2026-10-02 08:41:29.789516	2026-10-02 08:41:29.789516	9a802ef1-b3dc-4746-8548-8de0f05bb18e	cd63d325-f338-4d20-bfd6-8ec78caf4f5d	black-sun-glasses
38721858-1398-4f0d-8f3a-e0182193972e	Men Check Shirt	Smart check shirt for a polished look	3290	https://cdn.dummyjson.com/product-images/mens-shirts/men-check-shirt/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	18d46c8b-d817-48f2-be49-f711cf950405	f0bc81a0-15ef-49c6-92be-b07a436f6101	men-check-shirt
94e991cf-6b8b-4251-ba27-aef66a93c085	Corset Leather With Skirt	Bold leather corset paired with a matching skirt	8990	https://cdn.dummyjson.com/product-images/womens-dresses/corset-leather-with-skirt/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	c9c73a79-73c4-4332-9531-3440a7ec17a5	97755195-ea34-4fe3-96e3-b4fed03e6a21	corset-leather-with-skirt
64112509-ce88-4cd6-860e-b40c158dc230	Marni Red & Black Suit	Sophisticated red and black suit ensemble	17990	https://cdn.dummyjson.com/product-images/womens-dresses/marni-red-&-black-suit/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	c9c73a79-73c4-4332-9531-3440a7ec17a5	e346d242-2e56-4d7c-a81c-40dad2387e32	marni-red-black-suit
308012aa-cc81-4f2c-8a46-002fd1a38768	Gray Dress	Versatile neutral dress, easy to dress up or down	4590	https://cdn.dummyjson.com/product-images/tops/gray-dress/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	c9c73a79-73c4-4332-9531-3440a7ec17a5	f0bc81a0-15ef-49c6-92be-b07a436f6101	gray-dress
8177cca2-333d-4dd3-8acb-1e397271e7a4	Sports Sneakers Off White & Red	Off-white sneakers with bold red accents	7990	https://cdn.dummyjson.com/product-images/mens-shoes/sports-sneakers-off-white-&-red/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	9d83c9f7-3170-402c-8813-d0fe35564806	116f1764-9313-4a05-9eed-80c2309b4b01	sports-sneakers-off-white-red
5b6906fc-123b-45c2-849a-7c52164f679f	Calvin Klein Heel Shoes	Elegant heels for formal occasions	11990	https://cdn.dummyjson.com/product-images/womens-shoes/calvin-klein-heel-shoes/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	b48ef826-7196-41eb-8fe5-e40732151acf	97755195-ea34-4fe3-96e3-b4fed03e6a21	calvin-klein-heel-shoes
ee2b6a28-540b-4780-8d6f-5de6c2226c0c	Golden Shoes Woman	Glamorous golden shoes for special evenings	9490	https://cdn.dummyjson.com/product-images/womens-shoes/golden-shoes-woman/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	b48ef826-7196-41eb-8fe5-e40732151acf	0a3ee5ab-3fd7-4944-89a2-6bde2f7b141c	golden-shoes-woman
34ceeedd-1624-4260-b59b-f62f6b6ecfbb	Prada Women Bag	Iconic designer bag with the Prada logo	59990	https://cdn.dummyjson.com/product-images/womens-bags/prada-women-bag/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	02b3261d-d2b4-4fed-8150-89196a6c2057	ed57d8bc-99b3-494b-94d3-8a2b4f8c9e64	prada-women-bag
239a771d-345c-44a6-8c4b-5e0a3fc17a08	White Faux Leather Backpack	Trendy white backpack with plenty of space	6490	https://cdn.dummyjson.com/product-images/womens-bags/white-faux-leather-backpack/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	02b3261d-d2b4-4fed-8150-89196a6c2057	116f1764-9313-4a05-9eed-80c2309b4b01	white-faux-leather-backpack
ac80407e-b4ac-4888-83ac-d80249d0be27	Classic Sun Glasses	Timeless neutral frame with UV-protected lenses	2990	https://cdn.dummyjson.com/product-images/sunglasses/classic-sun-glasses/1.webp	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	2026-10-02 08:41:29.799621	2026-10-02 08:41:29.799621	35eacf02-538f-468a-9332-05b9e8f63de3	ed57d8bc-99b3-494b-94d3-8a2b4f8c9e64	classic-sun-glasses
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, text, rating, "userId", "updatedAt", "createdAt", "productId", "storeId") FROM stdin;
7b6f1db9-ce6c-4cc6-8792-04b61063a4dc	Great quality, will buy again!	5	f696a8a0-4279-4dbf-8e63-4767ea6e223f	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	1950b3cf-3fb3-4728-adc8-c033ffc297a6	85c0cfdf-2858-49ab-94ff-87ff644d1560
d692f43b-6178-494a-9bc2-be9eca64e693	Fits well, looks just like the photo.	4	f696a8a0-4279-4dbf-8e63-4767ea6e223f	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	cc60c459-3e8b-44f1-a119-e5501a533b9f	85c0cfdf-2858-49ab-94ff-87ff644d1560
b52b5717-ed2b-4153-8c2b-cd05545ad09a	Runs a bit small, but decent.	3	f696a8a0-4279-4dbf-8e63-4767ea6e223f	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	db8d2949-6204-4e6b-908c-00e6489421df	85c0cfdf-2858-49ab-94ff-87ff644d1560
87532162-66e2-42ad-8e65-cbcb33b39a0f	Good but a bit pricey.	4	f696a8a0-4279-4dbf-8e63-4767ea6e223f	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	76260181-938b-4e65-a418-c369f68c7e0b	85c0cfdf-2858-49ab-94ff-87ff644d1560
746edb11-adfb-4316-8730-4e128f330ed6	Absolutely love it, wear it all the time.	5	f696a8a0-4279-4dbf-8e63-4767ea6e223f	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	a798019d-68bb-4edb-b9e7-1a9c9266a460	85c0cfdf-2858-49ab-94ff-87ff644d1560
87c4f6ae-3514-472f-91ed-2a0977db1952	Great quality, will buy again!	5	f696a8a0-4279-4dbf-8e63-4767ea6e223f	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	b3dda725-5339-407e-bedb-e89f450d1b90	85c0cfdf-2858-49ab-94ff-87ff644d1560
e81b32cb-e968-4f6b-ad60-b7a149d21f0e	Fits well, looks just like the photo.	4	f696a8a0-4279-4dbf-8e63-4767ea6e223f	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	97940df8-d462-4f2c-afe9-0c788ada292e	85c0cfdf-2858-49ab-94ff-87ff644d1560
7216fe6a-9450-4782-95c6-43ef506891b3	Runs a bit small, but decent.	3	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	38721858-1398-4f0d-8f3a-e0182193972e	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
4edc0c88-6fcb-4424-961f-c29671707f91	Good but a bit pricey.	4	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	94e991cf-6b8b-4251-ba27-aef66a93c085	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
ebfb61ee-54c4-49df-a66c-139abca6d63d	Absolutely love it, wear it all the time.	5	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	64112509-ce88-4cd6-860e-b40c158dc230	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
9bef6d39-c118-4a34-ae8f-0ff95e6cd74c	Great quality, will buy again!	5	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	308012aa-cc81-4f2c-8a46-002fd1a38768	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
b153ea0d-91d9-47fb-895e-60df8b75626f	Fits well, looks just like the photo.	4	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	8177cca2-333d-4dd3-8acb-1e397271e7a4	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
0619ec9e-cfff-4dbc-bf2f-4bdafbe7bc3d	Runs a bit small, but decent.	3	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	5b6906fc-123b-45c2-849a-7c52164f679f	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
89f88617-79c6-49a1-9d63-4f22d8ac963b	Good but a bit pricey.	4	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	ee2b6a28-540b-4780-8d6f-5de6c2226c0c	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
c9c4df30-5dbe-49f7-a614-cfd8c1d3f51c	Absolutely love it, wear it all the time.	5	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	34ceeedd-1624-4260-b59b-f62f6b6ecfbb	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
fd6832ff-8e2f-42c0-b1a3-a5f4a6968369	Great quality, will buy again!	5	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	239a771d-345c-44a6-8c4b-5e0a3fc17a08	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
92bd3e5e-216c-4e99-bd48-945b45f93220	Fits well, looks just like the photo.	4	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.810669	2026-10-02 08:41:29.810669	ac80407e-b4ac-4888-83ac-d80249d0be27	8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stores (id, title, description, "userId", "updatedAt", "createdAt") FROM stdin;
85c0cfdf-2858-49ab-94ff-87ff644d1560	Serii Urban Wear	Everyday clothing, sneakers and accessories	054b8fdd-42a7-4108-bd69-c74599b5c616	2026-10-02 08:41:29.779094	2026-10-02 08:41:29.779094
8509a5d2-1ab8-4df1-b0a3-75f12c73e0f8	Nixon Boutique	Elegant dresses, shoes and designer bags	f696a8a0-4279-4dbf-8e63-4767ea6e223f	2026-10-02 08:41:29.793231	2026-10-02 08:41:29.793231
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_favorites ("usersId", "productsId") FROM stdin;
054b8fdd-42a7-4108-bd69-c74599b5c616	38721858-1398-4f0d-8f3a-e0182193972e
f696a8a0-4279-4dbf-8e63-4767ea6e223f	1950b3cf-3fb3-4728-adc8-c033ffc297a6
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, picture, password, "updatedAt", "createdAt") FROM stdin;
054b8fdd-42a7-4108-bd69-c74599b5c616	Serii	seriiburduja@gmail.com	/uploads/no-user-image.jpg	$argon2id$v=19$m=65536,p=4,t=3$I1H6Ztw8B+pBniHtxSDT9g$oYu2Xffa9sEpIMADE4ksSDIuWrWRg2DcRM87HTQTdAs	2026-10-02 08:41:29.769004	2026-10-02 08:41:29.769004
f696a8a0-4279-4dbf-8e63-4767ea6e223f	Nixon	nixon@gmail.com	/uploads/no-user-image.jpg	$argon2id$v=19$m=65536,p=4,t=3$I1H6Ztw8B+pBniHtxSDT9g$oYu2Xffa9sEpIMADE4ksSDIuWrWRg2DcRM87HTQTdAs	2026-10-02 08:41:29.769004	2026-10-02 08:41:29.769004
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 27, true);


--
-- Name: order_items PK_005269d8574e6fac0493715c308; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "PK_005269d8574e6fac0493715c308" PRIMARY KEY (id);


--
-- Name: products PK_0806c755e0aca124e67c0cf6d7d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "PK_0806c755e0aca124e67c0cf6d7d" PRIMARY KEY (id);


--
-- Name: reviews PK_231ae565c273ee700b283f15c1d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "PK_231ae565c273ee700b283f15c1d" PRIMARY KEY (id);


--
-- Name: categories PK_24dbc6126a28ff948da33e97d3b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "PK_24dbc6126a28ff948da33e97d3b" PRIMARY KEY (id);


--
-- Name: colors PK_3a62edc12d29307872ab1777ced; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "PK_3a62edc12d29307872ab1777ced" PRIMARY KEY (id);


--
-- Name: user_favorites PK_5065e45fbc2a1f3e58a6fd9a430; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT "PK_5065e45fbc2a1f3e58a6fd9a430" PRIMARY KEY ("usersId", "productsId");


--
-- Name: orders PK_710e2d4957aa5878dfe94e4ac2f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "PK_710e2d4957aa5878dfe94e4ac2f" PRIMARY KEY (id);


--
-- Name: stores PK_7aa6e7d71fa7acdd7ca43d7c9cb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT "PK_7aa6e7d71fa7acdd7ca43d7c9cb" PRIMARY KEY (id);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: categories UQ_00cd8c23464066489091473647d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "UQ_00cd8c23464066489091473647d" UNIQUE ("storeId", title);


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: products UQ_9844b96a2b5b3620eee675f805f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "UQ_9844b96a2b5b3620eee675f805f" UNIQUE ("storeId", slug);


--
-- Name: stores UQ_9f50895fbf54f7218dfa5b66e48; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT "UQ_9f50895fbf54f7218dfa5b66e48" UNIQUE ("userId", title);


--
-- Name: colors UQ_d0546798ebd98f0ffb35f3a2f0c; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "UQ_d0546798ebd98f0ffb35f3a2f0c" UNIQUE ("storeId", name);


--
-- Name: IDX_152cb1955a8e956ffb7645fdf4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_152cb1955a8e956ffb7645fdf4" ON public.user_favorites USING btree ("productsId");


--
-- Name: IDX_9b10bf53f6d16b355ce259098d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_9b10bf53f6d16b355ce259098d" ON public.user_favorites USING btree ("usersId");


--
-- Name: orders FK_151b79a83ba240b0cb31b2302d1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "FK_151b79a83ba240b0cb31b2302d1" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_favorites FK_152cb1955a8e956ffb7645fdf40; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT "FK_152cb1955a8e956ffb7645fdf40" FOREIGN KEY ("productsId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews FK_375e254056be23e89da0ef9ce13; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_375e254056be23e89da0ef9ce13" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: colors FK_517a6de81f2486324e0cdf5f0bd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT "FK_517a6de81f2486324e0cdf5f0bd" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: order_items FK_76b4a6406b4a79c62d165260a9c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_76b4a6406b4a79c62d165260a9c" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: products FK_782da5e50e94b763eb63225d69d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_782da5e50e94b763eb63225d69d" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: reviews FK_7ed5659e7139fc8bc039198cc1f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_7ed5659e7139fc8bc039198cc1f" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: products FK_977ca0c3cae8850c2a5f49e3f13; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_977ca0c3cae8850c2a5f49e3f13" FOREIGN KEY ("colorId") REFERENCES public.colors(id) ON DELETE CASCADE;


--
-- Name: user_favorites FK_9b10bf53f6d16b355ce259098d0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT "FK_9b10bf53f6d16b355ce259098d0" FOREIGN KEY ("usersId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews FK_a6b3c434392f5d10ec171043666; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "FK_a6b3c434392f5d10ec171043666" FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: order_items FK_cdb99c05982d5191ac8465ac010; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_cdb99c05982d5191ac8465ac010" FOREIGN KEY ("productId") REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: order_items FK_f1d359a55923bb45b057fbdab0d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "FK_f1d359a55923bb45b057fbdab0d" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: stores FK_f36d697e265ed99b80cae6984c9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT "FK_f36d697e265ed99b80cae6984c9" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: categories FK_fa6ba3528de12e174b163c09fdd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "FK_fa6ba3528de12e174b163c09fdd" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: products FK_ff56834e735fa78a15d0cf21926; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "FK_ff56834e735fa78a15d0cf21926" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict DdPpdM3koGHbKOPHGAwL9BA1QDlSF8Ixa3KfmvhovULqtnmCsQdNJzUoKvq811L

